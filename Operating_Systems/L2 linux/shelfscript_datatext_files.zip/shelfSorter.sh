#!/bin/bash
meny="ID\tNamn\t\tVikt\tL\tB\tH"

help(){
    echo -e "Usage: \tshelfsorter\t[-p | -s{i|n|v|l|b|h}]
    \nUsed primarily for sorting furniture data which is read through stdin.
    \n-p\t\tprint data contents and exit
    \n-s\t\tsort by additional argument : \nid(i), name(n), weight(v), length(l),\nwidth(b), height(h), print data contents and exit
    \n\t--help\tdisplay this help and exit" 
}

clean(){
    sed 's/\*/ /g'
}

if [ "$1" == "--help" ]; then
    help
    exit 0 
fi

if [ "$1" == "-p" ]; then
    echo -e "$meny"
    cat /dev/stdin | tr '|' '\t' | clean
    exit 0
elif [ "$1" == "-s" ]; then
    echo -e "$meny"
    case "$2" in
        i)
            cat /dev/stdin | tr '|' '\t' | sort -n -k1 | clean
            ;;
        n)
            cat /dev/stdin | tr '|' '\t' | sort -k2 | clean
            ;;
        v)
            cat /dev/stdin | tr '|' '\t' | sort -n -k3 | clean
            ;;
        l)
            cat /dev/stdin | tr '|' '\t' | sort -n -k4 | clean
            ;;
        b)
            cat /dev/stdin | tr '|' '\t' | sort -n -k5 | clean
            ;;
        h)
            cat /dev/stdin | tr '|' '\t' | sort -n -k6 | clean
            ;;
        *)
            echo "Invalid sort choice. Use --help for usage."
            exit 1
            ;;
    esac
else
    echo "Invalid option. Use --help for usage."
    exit 1
fi
